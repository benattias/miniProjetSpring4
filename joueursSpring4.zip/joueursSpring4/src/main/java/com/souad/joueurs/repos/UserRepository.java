package com.souad.joueurs.repos;
import org.springframework.data.jpa.repository.JpaRepository;
import com.souad.joueurs.entities.User;
public interface UserRepository extends JpaRepository<User, Long> {
User findByUsername (String username);
}